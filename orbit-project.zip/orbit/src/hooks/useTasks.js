import { useState, useEffect, useCallback, useRef } from 'react'
import { supabase } from '../lib/supabase'
import { fmtDate } from '../lib/constants'

const TODAY = new Date()

// ── LOCAL SEED (used when Supabase is not configured) ──
const SEED_TASKS = [
  {
    id: '1', job_id: 'emp1', name: 'Preparar apresentação para diretoria',
    priority: 'alta', due_date: fmtDate(new Date(TODAY.getFullYear(), TODAY.getMonth(), TODAY.getDate()+1)),
    recur: 'none', done: false, timer_total: 3240, sessions: 2,
    subtasks: [
      { id: '11', name: 'Definir estrutura dos slides', done: true },
      { id: '12', name: 'Montar gráficos de performance', done: true },
      { id: '13', name: 'Revisar com o gestor', done: false },
      { id: '14', name: 'Ensaio final', done: false },
    ],
  },
  {
    id: '2', job_id: 'emp1', name: 'Responder emails acumulados',
    priority: 'baixa', due_date: fmtDate(TODAY), recur: 'daily', done: false, timer_total: 0, sessions: 0,
    subtasks: [
      { id: '21', name: 'Filtrar urgentes', done: true },
      { id: '22', name: 'Responder clientes', done: false },
    ],
  },
  {
    id: '3', job_id: 'emp1', name: 'Revisar contrato com fornecedor',
    priority: 'media', due_date: fmtDate(new Date(TODAY.getFullYear(), TODAY.getMonth(), TODAY.getDate()+3)),
    recur: 'none', done: false, timer_total: 1800, sessions: 1,
    subtasks: [
      { id: '31', name: 'Ler cláusulas de rescisão', done: false },
      { id: '32', name: 'Consultar jurídico', done: false },
    ],
  },
  {
    id: '4', job_id: 'emp2', name: 'Sprint review — Produto B',
    priority: 'alta', due_date: fmtDate(new Date(TODAY.getFullYear(), TODAY.getMonth(), TODAY.getDate()+1)),
    recur: 'weekly', done: false, timer_total: 2700, sessions: 1,
    subtasks: [
      { id: '41', name: 'Compilar métricas do sprint', done: true },
      { id: '42', name: 'Slides de demo', done: false },
      { id: '43', name: 'Feedback do time', done: false },
    ],
  },
  {
    id: '5', job_id: 'emp2', name: 'Deploy da versão 2.1',
    priority: 'alta', due_date: fmtDate(TODAY), recur: 'none', done: true, timer_total: 5400, sessions: 3,
    subtasks: [
      { id: '51', name: 'Testes de regressão', done: true },
      { id: '52', name: 'Merge na main', done: true },
      { id: '53', name: 'Monitorar logs', done: true },
    ],
  },
  {
    id: '6', job_id: 'emp3', name: 'Entregar protótipo do site',
    priority: 'media', due_date: fmtDate(new Date(TODAY.getFullYear(), TODAY.getMonth(), TODAY.getDate()+5)),
    recur: 'none', done: false, timer_total: 7200, sessions: 4,
    subtasks: [
      { id: '61', name: 'Wireframes', done: true },
      { id: '62', name: 'Design visual', done: false },
      { id: '63', name: 'Versão mobile', done: false },
      { id: '64', name: 'Aprovação do cliente', done: false },
    ],
  },
  {
    id: '7', job_id: 'emp2', name: 'Reunião de alinhamento semanal',
    priority: 'baixa', due_date: fmtDate(new Date(TODAY.getFullYear(), TODAY.getMonth(), TODAY.getDate()+2)),
    recur: 'weekly', done: false, timer_total: 0, sessions: 0, subtasks: [],
  },
  {
    id: '8', job_id: 'emp3', name: 'Fatura de serviços',
    priority: 'alta', due_date: fmtDate(new Date(TODAY.getFullYear(), TODAY.getMonth(), TODAY.getDate()+3)),
    recur: 'monthly', done: false, timer_total: 900, sessions: 1,
    subtasks: [
      { id: '81', name: 'Calcular horas', done: true },
      { id: '82', name: 'Gerar PDF', done: false },
      { id: '83', name: 'Enviar para cliente', done: false },
    ],
  },
]

const isConfigured = () =>
  import.meta.env.VITE_SUPABASE_URL && import.meta.env.VITE_SUPABASE_ANON_KEY

export function useTasks(userId) {
  const [tasks, setTasks]   = useState(SEED_TASKS)
  const [loading, setLoading] = useState(false)
  const timerRef = useRef({})

  // ── LOAD ──
  const loadTasks = useCallback(async () => {
    if (!isConfigured() || !userId) return
    setLoading(true)
    const { data: taskRows } = await supabase
      .from('tasks')
      .select('*, subtasks(*)')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })

    if (taskRows) {
      setTasks(taskRows.map(t => ({
        ...t,
        job_id: t.job_id,
        timer_total: t.timer_total,
        due_date: t.due_date,
        subtasks: (t.subtasks || []).sort((a,b) => a.sort_order - b.sort_order),
      })))
    }
    setLoading(false)
  }, [userId])

  useEffect(() => { loadTasks() }, [loadTasks])

  // ── REALTIME ──
  useEffect(() => {
    if (!isConfigured() || !userId) return
    const channel = supabase
      .channel('tasks-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'tasks', filter: `user_id=eq.${userId}` }, loadTasks)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'subtasks' }, loadTasks)
      .subscribe()
    return () => supabase.removeChannel(channel)
  }, [userId, loadTasks])

  // ── CREATE TASK ──
  const createTask = useCallback(async ({ name, job_id, priority, due_date, recur, subtaskNames = [] }) => {
    const newId = crypto.randomUUID()
    const newTask = {
      id: newId, job_id, name, priority, due_date, recur,
      done: false, timer_total: 0, sessions: 0,
      subtasks: subtaskNames.map((n, i) => ({ id: crypto.randomUUID(), name: n, done: false, sort_order: i })),
    }

    // Optimistic update
    setTasks(prev => [newTask, ...prev])

    if (!isConfigured() || !userId) return newId

    const { data: task } = await supabase.from('tasks').insert({
      id: newId, user_id: userId, job_id, name, priority, due_date, recur,
    }).select().single()

    if (task && subtaskNames.length) {
      await supabase.from('subtasks').insert(
        subtaskNames.map((n, i) => ({
          task_id: task.id, user_id: userId, name: n, sort_order: i,
        }))
      )
    }
    return newId
  }, [userId])

  // ── TOGGLE TASK ──
  const toggleTask = useCallback(async (id) => {
    setTasks(prev => {
      const updated = prev.map(t => {
        if (t.id !== id) return t
        const newDone = !t.done
        // Handle recurrence
        if (newDone && t.recur !== 'none') {
          const base = new Date(t.due_date || TODAY)
          if (t.recur === 'daily')   base.setDate(base.getDate() + 1)
          else if (t.recur === 'weekly')  base.setDate(base.getDate() + 7)
          else                             base.setMonth(base.getMonth() + 1)
          const cloned = {
            ...t, id: crypto.randomUUID(), done: false, timer_total: 0, sessions: 0,
            due_date: fmtDate(base),
            subtasks: t.subtasks.map(s => ({ ...s, id: crypto.randomUUID(), done: false })),
          }
          setTimeout(() => setTasks(p => [cloned, ...p]), 0)
        }
        return { ...t, done: newDone }
      })
      return updated
    })

    if (!isConfigured() || !userId) return
    const task = tasks.find(t => t.id === id)
    if (!task) return
    await supabase.from('tasks').update({ done: !task.done }).eq('id', id)
    if (!task.done && task.recur !== 'none') {
      const base = new Date(task.due_date || TODAY)
      if (task.recur === 'daily') base.setDate(base.getDate() + 1)
      else if (task.recur === 'weekly') base.setDate(base.getDate() + 7)
      else base.setMonth(base.getMonth() + 1)
      const { data: newTask } = await supabase.from('tasks').insert({
        user_id: userId, job_id: task.job_id, name: task.name,
        priority: task.priority, due_date: fmtDate(base), recur: task.recur,
      }).select().single()
      if (newTask && task.subtasks.length) {
        await supabase.from('subtasks').insert(
          task.subtasks.map((s, i) => ({ task_id: newTask.id, user_id: userId, name: s.name, sort_order: i }))
        )
      }
    }
  }, [tasks, userId])

  // ── TOGGLE SUBTASK ──
  const toggleSubtask = useCallback(async (taskId, subId) => {
    setTasks(prev => prev.map(t => {
      if (t.id !== taskId) return t
      return { ...t, subtasks: t.subtasks.map(s => s.id === subId ? { ...s, done: !s.done } : s) }
    }))
    if (!isConfigured() || !userId) return
    const task = tasks.find(t => t.id === taskId)
    const sub  = task?.subtasks.find(s => s.id === subId)
    if (!sub) return
    await supabase.from('subtasks').update({ done: !sub.done }).eq('id', subId)
  }, [tasks, userId])

  // ── ADD SUBTASK ──
  const addSubtask = useCallback(async (taskId, name) => {
    const newSub = { id: crypto.randomUUID(), name, done: false, sort_order: Date.now() }
    setTasks(prev => prev.map(t => t.id === taskId ? { ...t, subtasks: [...t.subtasks, newSub] } : t))
    if (!isConfigured() || !userId) return
    await supabase.from('subtasks').insert({ task_id: taskId, user_id: userId, name, sort_order: newSub.sort_order })
  }, [userId])

  // ── TIMER ──
  const startTimer = useCallback((id) => {
    // stop any running timers
    setTasks(prev => prev.map(t => {
      if (!t._timerRunning) return t
      const elapsed = Math.floor((Date.now() - t._timerStart) / 1000)
      clearInterval(timerRef.current[t.id])
      return { ...t, timer_total: t.timer_total + elapsed, _timerRunning: false, _timerStart: null }
    }))
    // start new
    setTasks(prev => prev.map(t => t.id === id
      ? { ...t, _timerRunning: true, _timerStart: Date.now() }
      : t
    ))
  }, [])

  const stopTimer = useCallback(async (id) => {
    setTasks(prev => prev.map(t => {
      if (t.id !== id || !t._timerRunning) return t
      const elapsed = Math.floor((Date.now() - t._timerStart) / 1000)
      const newTotal = t.timer_total + elapsed
      if (isConfigured() && userId) {
        supabase.from('tasks').update({ timer_total: newTotal }).eq('id', id).then(() => {})
        supabase.from('timer_sessions').insert({
          task_id: id, user_id: userId,
          started_at: new Date(t._timerStart).toISOString(),
          ended_at: new Date().toISOString(),
          duration: elapsed,
        }).then(() => {})
      }
      return { ...t, timer_total: newTotal, _timerRunning: false, _timerStart: null }
    }))
  }, [userId])

  const toggleTimer = useCallback((id) => {
    const task = tasks.find(t => t.id === id)
    if (!task) return
    if (task._timerRunning) stopTimer(id)
    else startTimer(id)
  }, [tasks, startTimer, stopTimer])

  // ── TIMER TICK ──
  useEffect(() => {
    const iv = setInterval(() => {
      setTasks(prev => {
        const running = prev.filter(t => t._timerRunning)
        if (!running.length) return prev
        return prev.map(t => t._timerRunning ? { ...t, _tick: Date.now() } : t)
      })
    }, 1000)
    return () => clearInterval(iv)
  }, [])

  // ── SESSIONS (Pomodoro) ──
  const incrementSessions = useCallback(async (id) => {
    setTasks(prev => prev.map(t => t.id === id ? { ...t, sessions: t.sessions + 1 } : t))
    if (isConfigured() && userId) {
      const task = tasks.find(t => t.id === id)
      if (task) await supabase.from('tasks').update({ sessions: task.sessions + 1 }).eq('id', id)
    }
  }, [tasks, userId])

  return { tasks, loading, createTask, toggleTask, toggleSubtask, addSubtask, toggleTimer, incrementSessions, reload: loadTasks }
}
