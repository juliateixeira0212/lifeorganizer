import { JOBS_DEFAULT } from '../lib/constants'

const VIEWS = [
  ['tasks','Tarefas'], ['day','Dia'], ['week','Semana'], ['month','Mês'],
  ['kanban','Kanban'], ['gantt','Timeline'], ['analytics','Analytics'],
]

export default function Topbar({ view, onView, ctxMode, ctxJob, onOpenModal, onNotifications, onSignOut, isDemo }) {
  const j = JOBS_DEFAULT[ctxJob]
  return (
    <div className="topbar">
      <div className="brand">or<em>b</em>it</div>
      <div className="nav-tabs">
        {VIEWS.map(([v, label]) => (
          <button key={v} className={`nav-tab ${view===v?'active':''}`} onClick={() => onView(v)}>{label}</button>
        ))}
      </div>
      <div className="topbar-right">
        {ctxMode && j && (
          <span className="ctx-badge" style={{ background: j.bg, color: j.text, border: `1.5px solid ${j.color}` }}>
            Foco: {j.name}
          </span>
        )}
        <button className="icon-btn" onClick={onNotifications} title="Notificações">
          <svg viewBox="0 0 24 24"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 01-3.46 0"/></svg>
        </button>
        {!isDemo && (
          <button className="icon-btn" onClick={onSignOut} title="Sair">
            <svg viewBox="0 0 24 24"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9"/></svg>
          </button>
        )}
        <button className="add-btn" onClick={onOpenModal}>
          <svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>
          Nova tarefa
        </button>
      </div>
    </div>
  )
}
