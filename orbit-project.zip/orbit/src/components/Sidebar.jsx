import { JOBS_DEFAULT } from '../lib/constants'

const NAV_ITEMS = [
  ['tasks','Tarefas','M9 12l2 2 4-4M3 3h18v18H3z'],
  ['day','Dia','M3 4h18v18H3zM16 2v4M8 2v4M3 10h18M12 14v4M12 14h3'],
  ['week','Semana','M3 4h18v18H3zM16 2v4M8 2v4M3 10h18'],
  ['month','Mês','M3 4h18v18H3zM16 2v4M8 2v4M3 10h18M8 14h8M8 18h5'],
  ['kanban','Kanban','M3 3h5v18H3zM10 3h5v12h-5zM17 3h5v15h-5z'],
  ['analytics','Analytics','M22 12l-4 0-3 9-6-18-3 9-4 0'],
]
const TOOL_ITEMS = [
  ['templates','Templates','M3 3h18v18H3zM3 9h18M9 21V9'],
  ['integrations','Integrações','M9 7a4 4 0 100 8 4 4 0 000-8zM3 21v-2a4 4 0 014-4h4a4 4 0 014 4v2M16 3.13a4 4 0 010 7.75M21 21v-2a4 4 0 00-3-3.87'],
]

export default function Sidebar({ view, onView, activeJob, onJob, ctxMode, ctxJob, onToggleCtx, tasks }) {
  const j = JOBS_DEFAULT[ctxJob]
  const pending = tasks.filter(t => !t.done)

  return (
    <div className="sidebar">
      <div className="sb-sec">Empregos</div>
      <div className={`sb-item ${activeJob==='all'?'active':''}`} onClick={() => onJob('all')}>
        <svg className="sb-ico" viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
        Todos
        <span className="sb-cnt">{pending.length}</span>
      </div>
      {Object.entries(JOBS_DEFAULT).map(([jid, j]) => (
        <div key={jid} className={`sb-item ${activeJob===jid?'active':''}`} onClick={() => onJob(jid)}>
          <div className="sb-dot" style={{ background: j.color }} />
          {j.name}
          <span className="sb-cnt">{tasks.filter(t => t.job_id === jid && !t.done).length}</span>
        </div>
      ))}

      <div className="sb-div" />
      <div className="sb-sec">Vistas</div>
      {NAV_ITEMS.map(([v, label, path]) => (
        <div key={v} className={`sb-item ${view===v?'active':''}`} onClick={() => onView(v)}>
          <svg className="sb-ico" viewBox="0 0 24 24"><path d={path}/></svg>
          {label}
        </div>
      ))}

      <div className="sb-div" />
      <div className="sb-sec">Ferramentas</div>
      {TOOL_ITEMS.map(([v, label, path]) => (
        <div key={v} className={`sb-item ${view===v?'active':''}`} onClick={() => onView(v)}>
          <svg className="sb-ico" viewBox="0 0 24 24"><path d={path}/></svg>
          {label}
        </div>
      ))}

      <div className="sb-div" />
      <div className="sb-sec">Contexto</div>
      {ctxMode && j && (
        <div className="ctx-bar">
          <span className="ctx-bar-lbl">Modo foco ativo</span>
          <span className="ctx-bar-name">{j.name}</span>
        </div>
      )}
      <div className="sb-item" onClick={onToggleCtx}>
        <svg className="sb-ico" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M12 2v2M12 20v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M2 12h2M20 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>
        {ctxMode ? 'Desativar modo foco' : 'Ativar modo foco'}
      </div>
    </div>
  )
}
