import { useState, useEffect, useRef } from 'react'
import { JOBS_DEFAULT, PRIO, fmtDate, fmtDue, fmtTime } from '../lib/constants'

const TODAY = new Date()

export default function TaskCard({ task, onToggle, onToggleSub, onAddSub, onToggleTimer, onIncrSessions }) {
  const [expanded, setExpanded] = useState(false)
  const [showPomo, setShowPomo] = useState(false)
  const [pomoSecs, setPomoSecs] = useState(25 * 60)
  const [pomoRunning, setPomoRunning] = useState(false)
  const pomoRef = useRef(null)

  const j = JOBS_DEFAULT[task.job_id] || JOBS_DEFAULT.emp1
  const p = PRIO[task.priority] || PRIO.media

  const tot = task.subtasks?.length || 0
  const dc  = task.subtasks?.filter(s => s.done).length || 0
  const pct = tot ? Math.round(dc / tot * 100) : 0

  const isOver    = task.due_date && task.due_date < fmtDate(TODAY) && !task.done
  const isRunning = task._timerRunning
  const liveSecs  = isRunning
    ? task.timer_total + Math.floor((Date.now() - task._timerStart) / 1000)
    : task.timer_total

  // Pomodoro
  useEffect(() => {
    if (!pomoRunning) return
    pomoRef.current = setInterval(() => {
      setPomoSecs(s => {
        if (s <= 1) {
          clearInterval(pomoRef.current)
          setPomoRunning(false)
          onIncrSessions?.(task.id)
          return 25 * 60
        }
        return s - 1
      })
    }, 1000)
    return () => clearInterval(pomoRef.current)
  }, [pomoRunning, task.id, onIncrSessions])

  const handleAddSub = () => {
    const name = window.prompt('Nome da subtarefa:')
    if (name?.trim()) onAddSub?.(task.id, name.trim())
  }

  const RECUR_LABELS = { daily: 'Diária', weekly: 'Semanal', monthly: 'Mensal' }

  return (
    <div className={`task-card ${expanded ? 'expanded' : ''} ${isRunning ? 'running' : ''}`} id={`tc-${task.id}`}>
      <div className="tc-top">
        <div className={`tc-cb ${task.done ? 'done' : ''}`} onClick={() => onToggle(task.id)}>
          {task.done && <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>}
        </div>

        <div className="tc-body">
          <div className={`tc-name ${task.done ? 'done' : ''}`}>{task.name}</div>
          <div className="tc-meta">
            <span className="tc-badge" style={{ background: p.bg, color: p.color }}>{p.label}</span>
            <span className="tc-badge" style={{ background: j.bg, color: j.text }}>{j.name}</span>
            {task.due_date && (
              <span className={`tc-due ${isOver ? 'over' : ''}`}>
                <svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>
                {fmtDue(task.due_date, TODAY)}
              </span>
            )}
            {task.recur && task.recur !== 'none' && (
              <span style={{ fontSize: 9, color: 'var(--t3)', padding: '2px 7px', borderRadius: 10, border: '1.5px solid var(--b1)', fontWeight: 600 }}>
                {RECUR_LABELS[task.recur]}
              </span>
            )}
            {liveSecs > 0 && (
              <span className="tc-timer">
                <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/></svg>
                {fmtTime(liveSecs)}
              </span>
            )}
          </div>
        </div>

        <div className="tc-acts">
          <button className={`tc-ib ${isRunning ? 'active' : ''}`} onClick={() => onToggleTimer(task.id)} title={isRunning ? 'Parar' : 'Iniciar'}>
            <svg viewBox="0 0 24 24">
              {isRunning
                ? <><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></>
                : <polygon points="5 3 19 12 5 21 5 3"/>}
            </svg>
          </button>
          {tot > 0 && (
            <button className="tc-ib" onClick={() => setShowPomo(p => !p)} title="Pomodoro">
              <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/></svg>
            </button>
          )}
          {tot > 0 && (
            <button className="tc-ib" onClick={() => setExpanded(e => !e)}>
              <svg viewBox="0 0 24 24" className={`chev ${expanded ? 'open' : ''}`}><polyline points="6 9 12 15 18 9"/></svg>
            </button>
          )}
        </div>
      </div>

      {/* Subtasks */}
      {tot > 0 && (
        <div className={`sub-wrap ${expanded ? 'open' : ''}`}>
          <div className="prog-row">
            <span style={{ fontSize: 10, color: 'var(--t3)', fontWeight: 500 }}>Subtarefas {dc}/{tot}</span>
            <div className="prog-bar"><div className="prog-fill" style={{ width: `${pct}%`, background: j.color }} /></div>
            <span className="prog-pct">{pct}%</span>
          </div>
          {task.subtasks.map(s => (
            <div key={s.id} className="sub-row">
              <div className={`sub-cb ${s.done ? 'done' : ''}`} onClick={() => onToggleSub(task.id, s.id)}>
                {s.done && <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>}
              </div>
              <div className={`sub-name ${s.done ? 'done' : ''}`}>{s.name}</div>
            </div>
          ))}
          <div className="sub-add" onClick={handleAddSub}>
            <svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>
            <span>Adicionar subtarefa</span>
          </div>
        </div>
      )}

      {/* Pomodoro */}
      {showPomo && (
        <div className="pomo-wrap open">
          <div className="pomo-inner">
            <div className="pomo-lbl">Modo foco — Pomodoro</div>
            <div className="pomo-time">
              {String(Math.floor(pomoSecs / 60)).padStart(2,'0')}:{String(pomoSecs % 60).padStart(2,'0')}
            </div>
            <div className="pomo-btns">
              <button className={`pomo-btn primary`} onClick={() => setPomoRunning(r => !r)}>
                {pomoRunning ? 'Pausar' : 'Iniciar'}
              </button>
              <button className="pomo-btn" onClick={() => { setPomoRunning(false); setPomoSecs(25*60) }}>Reset</button>
              <button className="pomo-btn" onClick={() => setShowPomo(false)}>Fechar</button>
            </div>
            <div className="pomo-sess">
              {Array.from({ length: 4 }, (_, i) => (
                <div key={i} className={`pomo-dot ${i < task.sessions % 4 ? 'done' : ''}`} />
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
