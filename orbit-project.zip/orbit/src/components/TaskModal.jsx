import { useState, useEffect } from 'react'
import { fmtDate } from '../lib/constants'

const TODAY = new Date()

export default function TaskModal({ open, onClose, onCreate, defaultJob }) {
  const [title, setTitle]   = useState('')
  const [job, setJob]       = useState(defaultJob || 'emp1')
  const [due, setDue]       = useState(fmtDate(TODAY))
  const [prio, setPrio]     = useState('media')
  const [recur, setRecur]   = useState('none')
  const [subs, setSubs]     = useState('')
  const [saving, setSaving] = useState(false)

  useEffect(() => { if (defaultJob) setJob(defaultJob) }, [defaultJob])
  useEffect(() => {
    if (!open) { setTitle(''); setSubs(''); setPrio('media'); setRecur('none') }
  }, [open])

  useEffect(() => {
    const fn = (e) => { if (e.key === 'Escape') onClose() }
    document.addEventListener('keydown', fn)
    return () => document.removeEventListener('keydown', fn)
  }, [onClose])

  const save = async () => {
    if (!title.trim()) return
    setSaving(true)
    await onCreate({
      name: title.trim(),
      job_id: job,
      priority: prio,
      due_date: due,
      recur,
      subtaskNames: subs.split('\n').filter(s => s.trim()),
    })
    setSaving(false)
  }

  const PRIOS = [['alta','Alta','var(--ph)'],['media','Média','var(--pm)'],['baixa','Baixa','var(--pl)']]
  const RECURS = [['none','Nenhuma'],['daily','Diária'],['weekly','Semanal'],['monthly','Mensal']]

  return (
    <div className={`modal-ov ${open?'open':''}`} onClick={e => e.target===e.currentTarget&&onClose()}>
      <div className="modal-box">
        <div className="modal-title">Nova tarefa</div>

        <div className="modal-field">
          <label className="modal-label">Título</label>
          <input className="modal-input" placeholder="O que precisa ser feito?" value={title} onChange={e=>setTitle(e.target.value)} autoFocus />
        </div>

        <div className="modal-row">
          <div className="modal-field" style={{margin:0}}>
            <label className="modal-label">Emprego</label>
            <select className="modal-input" value={job} onChange={e=>setJob(e.target.value)}>
              <option value="emp1">Emprego 1</option>
              <option value="emp2">Emprego 2</option>
              <option value="emp3">Freelance</option>
            </select>
          </div>
          <div className="modal-field" style={{margin:0}}>
            <label className="modal-label">Prazo</label>
            <input className="modal-input" type="date" value={due} onChange={e=>setDue(e.target.value)} />
          </div>
        </div>

        <div className="modal-field">
          <label className="modal-label">Prioridade</label>
          <div className="prio-grid">
            {PRIOS.map(([p,label,color]) => (
              <div key={p} className={`prio-opt ${prio===p?'active':''}`} style={{color}} onClick={()=>setPrio(p)}>{label}</div>
            ))}
          </div>
        </div>

        <div className="modal-field">
          <label className="modal-label">Recorrência</label>
          <div className="recur-grid">
            {RECURS.map(([r,label]) => (
              <div key={r} className={`recur-opt ${recur===r?'active':''}`} onClick={()=>setRecur(r)}>{label}</div>
            ))}
          </div>
        </div>

        <div className="modal-field">
          <label className="modal-label">Subtarefas (uma por linha)</label>
          <textarea className="modal-input" rows={3} placeholder={'Esboçar estrutura\nRevisar com a equipa\nEnviar para aprovação'} value={subs} onChange={e=>setSubs(e.target.value)} style={{resize:'none',lineHeight:1.6}} />
        </div>

        <div className="modal-acts">
          <button className="modal-cancel" onClick={onClose}>Cancelar</button>
          <button className="modal-save" onClick={save} disabled={saving}>{saving ? 'a guardar...' : 'Criar tarefa'}</button>
        </div>
      </div>
    </div>
  )
}
