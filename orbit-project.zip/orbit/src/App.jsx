import { useState, useCallback } from 'react'
import { useAuth } from './hooks/useAuth'
import { useTasks } from './hooks/useTasks'
import { JOBS_DEFAULT, TEMPLATES, fmtDate, fmtDue, fmtTime, MONTHS, DAYS, PRIO } from './lib/constants'
import AuthScreen from './views/AuthScreen'
import Topbar from './components/Topbar'
import Sidebar from './components/Sidebar'
import TaskModal from './components/TaskModal'
import TasksView from './views/TasksView'
import DayView from './views/DayView'
import WeekView from './views/WeekView'
import MonthView from './views/MonthView'
import KanbanView from './views/KanbanView'
import GanttView from './views/GanttView'
import AnalyticsView from './views/AnalyticsView'
import NotificationsView from './views/NotificationsView'
import TemplatesView from './views/TemplatesView'
import IntegrationsView from './views/IntegrationsView'

const TODAY = new Date()

export default function App() {
  const { user, loading: authLoading, signIn, signUp, signOut, signInWithGoogle } = useAuth()
  const { tasks, loading, createTask, toggleTask, toggleSubtask, addSubtask, toggleTimer, incrementSessions } = useTasks(user?.id)

  const [view, setView]           = useState('tasks')
  const [activeJob, setActiveJob] = useState('all')
  const [ctxMode, setCtxMode]     = useState(false)
  const [ctxJob, setCtxJob]       = useState('emp1')
  const [modalOpen, setModalOpen] = useState(false)
  const [modalJob, setModalJob]   = useState(null)
  const [dayOff, setDayOff]       = useState(0)
  const [weekOff, setWeekOff]     = useState(0)
  const [monthOff, setMonthOff]   = useState(0)

  // Demo mode (no Supabase configured)
  const isDemo = !import.meta.env.VITE_SUPABASE_URL

  const openModal = useCallback((job = null) => { setModalJob(job); setModalOpen(true) }, [])
  const closeModal = useCallback(() => setModalOpen(false), [])

  const handleCreateTask = useCallback(async (data) => {
    const id = await createTask(data)
    closeModal()
    setView('tasks')
    return id
  }, [createTask, closeModal])

  const handleUseTemplate = useCallback(async (tplName, jobId) => {
    const tpl = TEMPLATES.find(t => t.name === tplName)
    if (!tpl) return
    await createTask({
      name: tpl.name, job_id: jobId, priority: 'media',
      due_date: fmtDate(TODAY), recur: 'none',
      subtaskNames: tpl.tasks,
    })
    setView('tasks')
  }, [createTask])

  const toggleCtx = useCallback(() => {
    if (!ctxMode) {
      const j = activeJob === 'all' ? 'emp1' : activeJob
      setCtxMode(true); setCtxJob(j); setActiveJob(j)
    } else {
      setCtxMode(false); setActiveJob('all')
    }
  }, [ctxMode, activeJob])

  if (authLoading) return (
    <div style={{ display:'flex', alignItems:'center', justifyContent:'center', height:'100vh', color:'var(--t3)', fontFamily:'var(--sans)' }}>
      carregando...
    </div>
  )

  if (!isDemo && !user) return (
    <AuthScreen onSignIn={signIn} onSignUp={signUp} onGoogle={signInWithGoogle} />
  )

  const VIEWS = ['tasks','day','week','month','kanban','gantt','analytics','notifications','templates','integrations']

  return (
    <div className="app">
      <Topbar
        view={view} onView={setView}
        ctxMode={ctxMode} ctxJob={ctxJob}
        onOpenModal={() => openModal()}
        onNotifications={() => setView('notifications')}
        onSignOut={signOut} isDemo={isDemo}
      />
      <div className="body">
        <Sidebar
          view={view} onView={setView}
          activeJob={activeJob} onJob={setActiveJob}
          ctxMode={ctxMode} ctxJob={ctxJob} onToggleCtx={toggleCtx}
          tasks={tasks}
        />
        <div className="content">
          {view === 'tasks'         && <TasksView tasks={tasks} activeJob={activeJob} onToggleTask={toggleTask} onToggleSub={toggleSubtask} onAddSub={addSubtask} onToggleTimer={toggleTimer} onIncrSessions={incrementSessions} onOpenModal={openModal} />}
          {view === 'day'           && <DayView tasks={tasks} dayOff={dayOff} onShift={setDayOff} />}
          {view === 'week'          && <WeekView tasks={tasks} weekOff={weekOff} onShift={setWeekOff} onGoDay={(off) => { setDayOff(off); setView('day') }} />}
          {view === 'month'         && <MonthView tasks={tasks} monthOff={monthOff} onShift={setMonthOff} onGoDay={(off) => { setDayOff(off); setView('day') }} />}
          {view === 'kanban'        && <KanbanView tasks={tasks} />}
          {view === 'gantt'         && <GanttView tasks={tasks} />}
          {view === 'analytics'     && <AnalyticsView tasks={tasks} />}
          {view === 'notifications' && <NotificationsView tasks={tasks} />}
          {view === 'templates'     && <TemplatesView onUse={handleUseTemplate} />}
          {view === 'integrations'  && <IntegrationsView />}
        </div>
      </div>

      {/* Mobile tabbar */}
      <div className="mobile-tabbar">
        <div className="mob-tabs">
          {[
            ['tasks','Tarefas','M9 12l2 2 4-4M3 3h18v18H3z'],
            ['day','Dia','M3 4h18v18H3zM16 2v4M8 2v4M3 10h18M12 14v4M12 14h3'],
            ['week','Semana','M3 4h18v18H3zM16 2v4M8 2v4M3 10h18'],
            ['month','Mês','M3 4h18v18H3zM16 2v4M8 2v4M3 10h18M8 14h8M8 18h5'],
            ['analytics','Stats','M22 12l-4 0-3 9-6-18-3 9-4 0'],
          ].map(([v, label, path]) => (
            <button key={v} className={`mob-tab ${view===v?'active':''}`} onClick={() => setView(v)}>
              <svg viewBox="0 0 24 24"><path d={path}/></svg>
              {label}
            </button>
          ))}
        </div>
      </div>

      <TaskModal
        open={modalOpen} onClose={closeModal}
        onCreate={handleCreateTask}
        defaultJob={modalJob}
      />
    </div>
  )
}
