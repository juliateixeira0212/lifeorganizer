import { JOBS_DEFAULT, fmtDate } from '../lib/constants'

const TODAY = new Date()
const TOTAL_DAYS = 28

export default function GanttView({ tasks }) {
  const sorted = [...tasks].filter(t => !t.done).sort((a,b) => (a.due_date||'9999') > (b.due_date||'9999') ? 1 : -1)
  const markers = Array.from({ length: 5 }, (_, i) => { const d = new Date(TODAY); d.setDate(d.getDate() + i*7); return `${d.getDate()}/${d.getMonth()+1}` })

  const dayPct = (ds) => {
    const diff = Math.floor((new Date(ds) - TODAY) / 864e5)
    return Math.max(0, Math.min(100, (diff / TOTAL_DAYS) * 100))
  }

  return (
    <div>
      <div className="view-header"><div className="vh-title">Linha do tempo — próximas 4 semanas</div></div>
      <div className="gantt-wrap">
        <div style={{ display: 'flex', gap: 10, marginBottom: 8 }}>
          <div style={{ width: 160, flexShrink: 0, fontSize: 9, color: 'var(--t4)', fontWeight: 600 }}>Tarefa</div>
          <div style={{ flex: 1, display: 'flex' }}>
            {markers.map((m, i) => <div key={i} style={{ flex: 'none', width: '25%', textAlign: 'center', fontSize: 9, color: 'var(--t4)', fontWeight: 500 }}>{m}</div>)}
          </div>
        </div>
        {sorted.map(t => {
          const j = JOBS_DEFAULT[t.job_id] || JOBS_DEFAULT.emp1
          const due = t.due_date || fmtDate(new Date(TODAY.getTime() + TOTAL_DAYS * 864e5))
          const w   = Math.max(3, dayPct(due))
          const pct = t.subtasks.length ? Math.round(t.subtasks.filter(s=>s.done).length / t.subtasks.length * 100) : 0
          return (
            <div key={t.id} className="gantt-row">
              <div className="gantt-lbl">{t.name}</div>
              <div className="gantt-area">
                <div className="gantt-bar" style={{ left: 0, width: `${w}%`, background: j.bg, borderLeftColor: j.color }}>
                  <span className="gantt-bar-txt" style={{ color: j.text }}>{t.name}</span>
                </div>
                {pct > 0 && (
                  <div style={{ position:'absolute', top:2, left:0, width:`${w*pct/100}%`, height:18, background:j.color, opacity:.35, borderRadius:8 }} />
                )}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
