import { JOBS_DEFAULT, MONTHS, DAYS, fmtDate } from '../lib/constants'

const TODAY = new Date()

export default function MonthView({ tasks, monthOff, onShift, onGoDay }) {
  const base     = new Date(TODAY.getFullYear(), TODAY.getMonth() + monthOff, 1)
  const firstDay = base.getDay()
  const dim      = new Date(base.getFullYear(), base.getMonth() + 1, 0).getDate()
  const pdim     = new Date(base.getFullYear(), base.getMonth(), 0).getDate()
  let cells = []
  for (let i = firstDay - 1; i >= 0; i--) cells.push({ d: pdim - i, cur: false })
  for (let d = 1; d <= dim; d++) cells.push({ d, cur: true })
  while (cells.length % 7) cells.push({ d: cells.length - dim - firstDay + 1, cur: false })

  return (
    <div>
      <div className="view-header">
        <div className="vh-nav">
          <button className="nav-arr" onClick={() => onShift(monthOff - 1)}>
            <svg viewBox="0 0 24 24"><polyline points="15 18 9 12 15 6"/></svg>
          </button>
          <div className="vh-title">{MONTHS[base.getMonth()]} {base.getFullYear()}</div>
          <button className="nav-arr" onClick={() => onShift(monthOff + 1)}>
            <svg viewBox="0 0 24 24"><polyline points="9 18 15 12 9 6"/></svg>
          </button>
        </div>
      </div>

      <div className="month-grid">
        {DAYS.map(d => <div key={d} className="mth-head">{d}</div>)}
        {cells.map((c, idx) => {
          if (!c.cur) return <div key={idx} className="mth-cell other"><div className="mc-n">{c.d}</div></div>
          const ds   = `${base.getFullYear()}-${String(base.getMonth()+1).padStart(2,'0')}-${String(c.d).padStart(2,'0')}`
          const isT  = ds === fmtDate(TODAY)
          const evs  = tasks.filter(t => t.due_date === ds)
          const vis  = evs.slice(0, 3)
          const more = evs.length - 3
          const diff = Math.floor((new Date(ds) - TODAY) / 864e5)
          return (
            <div key={idx} className={`mth-cell ${isT ? 'today-cell' : ''}`} onClick={() => onGoDay(diff)}>
              <div className={`mc-n ${isT ? 'today-n' : ''}`}>{c.d}</div>
              {vis.map(t => {
                const j = JOBS_DEFAULT[t.job_id] || JOBS_DEFAULT.emp1
                return <div key={t.id} className="mc-ev" style={{ background: j.bg, color: j.text }}>{t.name}</div>
              })}
              {more > 0 && <div className="mc-more">+{more} mais</div>}
            </div>
          )
        })}
      </div>
    </div>
  )
}
