import { useState } from 'react'
import { TEMPLATES, JOBS_DEFAULT } from '../lib/constants'

export default function TemplatesView({ onUse }) {
  const [picking, setPicking] = useState(null) // tpl name being picked

  return (
    <div className="tpl-grid">
      {TEMPLATES.map((tpl, ti) => (
        <div key={ti} className="tpl-card">
          <div className="tpl-ico" style={{ background: tpl.color + '18', color: tpl.color }}>
            <svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/></svg>
          </div>
          <div className="tpl-name">{tpl.emoji} {tpl.name}</div>
          <div className="tpl-desc">{tpl.desc}</div>
          {tpl.tasks.map((task, i) => <div key={i} className="tpl-tr">{task}</div>)}

          {picking === tpl.name ? (
            <div className="tpl-pick">
              <div className="tpl-pick-lbl">Em qual emprego?</div>
              <div>
                {Object.entries(JOBS_DEFAULT).map(([jid, j]) => (
                  <button
                    key={jid} className="tpl-job-btn"
                    style={{ border: `1.5px solid ${j.color}`, background: j.bg, color: j.text }}
                    onClick={() => { onUse(tpl.name, jid); setPicking(null) }}
                  >
                    {j.name}
                  </button>
                ))}
                <button className="tpl-cancel-btn" onClick={() => setPicking(null)}>Cancelar</button>
              </div>
            </div>
          ) : (
            <button className="tpl-use" onClick={() => setPicking(tpl.name)}>Usar template ✦</button>
          )}
        </div>
      ))}
    </div>
  )
}
