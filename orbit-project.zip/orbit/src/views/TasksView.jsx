import { JOBS_DEFAULT, PRIO, fmtDate } from '../lib/constants'
import TaskCard from '../components/TaskCard'

const TODAY = new Date()

export default function TasksView({ tasks, activeJob, onToggleTask, onToggleSub, onAddSub, onToggleTimer, onIncrSessions, onOpenModal }) {
  const filtered = activeJob === 'all' ? tasks : tasks.filter(t => t.job_id === activeJob)
  const jobs     = activeJob === 'all' ? Object.keys(JOBS_DEFAULT) : [activeJob]
  const cols     = jobs.length === 1 ? '1fr' : jobs.length === 2 ? '1fr 1fr' : '1fr 1fr 1fr'

  const pending = tasks.filter(t => !t.done)
  const done    = tasks.filter(t => t.done)
  const high    = tasks.filter(t => t.priority === 'alta' && !t.done)
  const totalHrs = (tasks.reduce((a, t) => a + t.timer_total, 0) / 3600).toFixed(1)
  const dueToday = tasks.filter(t => !t.done && t.due_date === fmtDate(TODAY))

  const top3 = [...tasks].filter(t => !t.done)
    .sort((a, b) => {
      const pa = { alta: 0, media: 1, baixa: 2 }
      if (pa[a.priority] !== pa[b.priority]) return pa[a.priority] - pa[b.priority]
      return (a.due_date || '9999') > (b.due_date || '9999') ? 1 : -1
    }).slice(0, 3)

  const goTask = (id) => {
    setTimeout(() => {
      const el = document.getElementById(`tc-${id}`)
      if (el) { el.scrollIntoView({ behavior: 'smooth', block: 'center' }); el.style.borderColor = 'var(--ac)'; setTimeout(() => el.style.borderColor = '', 1200) }
    }, 50)
  }

  return (
    <div>
      {/* Stats */}
      <div className="stats-row">
        <div className="stat-card">
          <div className="stat-val">{pending.length}</div>
          <div className="stat-label">Pendentes</div>
          {dueToday.length > 0 && <div className="stat-sub">{dueToday.length} vencem hoje</div>}
        </div>
        <div className="stat-card">
          <div className="stat-val">{done.length}</div>
          <div className="stat-label">Concluídas</div>
        </div>
        <div className="stat-card">
          <div className="stat-val">{high.length}</div>
          <div className="stat-label">Alta prioridade</div>
        </div>
        <div className="stat-card">
          <div className="stat-val">{totalHrs}h</div>
          <div className="stat-label">Horas registadas</div>
          <div className="stat-sub">esta semana</div>
        </div>
      </div>

      {/* AI strip */}
      {top3.length > 0 && (
        <div className="ai-strip">
          <div className="ai-ico">
            <svg viewBox="0 0 24 24"><path d="M12 2a10 10 0 110 20A10 10 0 0112 2z"/><path d="M12 8v4l3 3" strokeLinecap="round"/></svg>
          </div>
          <div style={{ flex: 1 }}>
            <div className="ai-lbl">Sugestão de foco para hoje</div>
            <div className="ai-tasks">
              {top3.map(t => (
                <div key={t.id} className="ai-pill" onClick={() => goTask(t.id)}>
                  {t.name.length > 32 ? t.name.slice(0, 32) + '…' : t.name}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Job columns */}
      <div style={{ display: 'grid', gridTemplateColumns: cols, gap: 16 }}>
        {jobs.map(jid => {
          const j = JOBS_DEFAULT[jid]
          const jt = filtered.filter(t => t.job_id === jid)
          const pend = jt.filter(t => !t.done)
          const dn   = jt.filter(t => t.done)
          return (
            <div key={jid}>
              <div className="jc-head">
                <div style={{ width: 9, height: 9, borderRadius: '50%', background: j.color }} />
                <div className="jc-name">{j.name}</div>
                <div className="jc-cnt">{pend.length}</div>
                <button className="jc-add" onClick={() => onOpenModal(jid)}>+</button>
              </div>
              {pend.map(t => (
                <TaskCard key={t.id} task={t}
                  onToggle={onToggleTask} onToggleSub={onToggleSub}
                  onAddSub={onAddSub} onToggleTimer={onToggleTimer}
                  onIncrSessions={onIncrSessions}
                />
              ))}
              {dn.length > 0 && (
                <>
                  <div className="done-lbl">Concluídas</div>
                  {dn.map(t => (
                    <TaskCard key={t.id} task={t}
                      onToggle={onToggleTask} onToggleSub={onToggleSub}
                      onAddSub={onAddSub} onToggleTimer={onToggleTimer}
                      onIncrSessions={onIncrSessions}
                    />
                  ))}
                </>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
