// WeekView
import { JOBS_DEFAULT, MONTHS, DAYS, fmtDate } from '../lib/constants'

const TODAY = new Date()
const HOURS = [8,9,10,11,12,13,14,15,16,17,18]

export default function WeekView({ tasks, weekOff, onShift, onGoDay }) {
  const base = new Date(2026, 3, 26); base.setDate(base.getDate() + weekOff * 7)
  const days = Array.from({ length: 7 }, (_, i) => { const d = new Date(base); d.setDate(base.getDate() + i); return d })
  const sun  = days[6]

  return (
    <div>
      <div className="view-header">
        <div className="vh-nav">
          <button className="nav-arr" onClick={() => onShift(weekOff - 1)}>
            <svg viewBox="0 0 24 24"><polyline points="15 18 9 12 15 6"/></svg>
          </button>
          <div className="vh-title">
            {days[0].getDate()} {MONTHS[days[0].getMonth()].slice(0,3)} — {sun.getDate()} {MONTHS[sun.getMonth()].slice(0,3)} {sun.getFullYear()}
          </div>
          <button className="nav-arr" onClick={() => onShift(weekOff + 1)}>
            <svg viewBox="0 0 24 24"><polyline points="9 18 15 12 9 6"/></svg>
          </button>
        </div>
        <button className="today-btn" onClick={() => onShift(0)}>Hoje</button>
      </div>

      <div className="week-grid">
        <div className="wg-corner" />
        {days.map((d, i) => {
          const isT = d.toDateString() === TODAY.toDateString()
          const diff = Math.floor((d - TODAY) / 864e5)
          return (
            <div key={i} className="wg-dh">
              <div className="wgd-nm">{DAYS[d.getDay()]}</div>
              <div className={`wgd-n ${isT ? 'today-n' : ''}`} onClick={() => onGoDay(diff)}>{d.getDate()}</div>
            </div>
          )
        })}
        {HOURS.map(h => (
          <>
            <div key={`tl-${h}`} className="wg-tl">{h}h</div>
            {days.map((d, i) => {
              const isT = d.toDateString() === TODAY.toDateString()
              const ds  = fmtDate(d)
              const evs = h === 9 ? tasks.filter(t => t.due_date === ds && !t.done) : []
              return (
                <div key={`slot-${h}-${i}`} className={`wg-slot ${isT ? 'today-c' : ''}`}>
                  {evs.map(t => {
                    const j = JOBS_DEFAULT[t.job_id] || JOBS_DEFAULT.emp1
                    return (
                      <div key={t.id} className="wg-ev" style={{ background: j.bg, borderLeftColor: j.color }}>
                        <div className="wg-ev-nm" style={{ color: j.text }}>{t.name}</div>
                      </div>
                    )
                  })}
                </div>
              )
            })}
          </>
        ))}
      </div>
    </div>
  )
}
