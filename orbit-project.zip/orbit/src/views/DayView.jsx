import { JOBS_DEFAULT, MONTHS, DAYS, fmtDate } from '../lib/constants'

const TODAY = new Date()
const HOURS = [7,8,9,10,11,12,13,14,15,16,17,18,19,20]

export default function DayView({ tasks, dayOff, onShift }) {
  const d = new Date(TODAY); d.setDate(d.getDate() + dayOff)
  const ds = fmtDate(d)
  const isToday = ds === fmtDate(TODAY)
  const dayTasks = tasks.filter(t => t.due_date === ds)
  const nowHour = isToday ? new Date().getHours() : -1

  // distribute tasks across hours starting at 9
  const tasksByHour = {}
  dayTasks.forEach((t, i) => {
    const h = Math.min(9 + Math.floor(i / 2), 18)
    if (!tasksByHour[h]) tasksByHour[h] = []
    tasksByHour[h].push(t)
  })

  return (
    <div>
      <div className="view-header">
        <div className="vh-nav">
          <button className="nav-arr" onClick={() => onShift(dayOff - 1)}>
            <svg viewBox="0 0 24 24"><polyline points="15 18 9 12 15 6"/></svg>
          </button>
          <div className="vh-title">{DAYS[d.getDay()]}, {d.getDate()} de {MONTHS[d.getMonth()]}</div>
          <button className="nav-arr" onClick={() => onShift(dayOff + 1)}>
            <svg viewBox="0 0 24 24"><polyline points="9 18 15 12 9 6"/></svg>
          </button>
        </div>
        <button className="today-btn" onClick={() => onShift(0)}>Hoje</button>
      </div>

      <div className="day-grid">
        {/* Header */}
        <div className="day-header">
          <div className="day-header-pad" />
          <div className={`day-header-main ${isToday ? 'is-today' : ''}`}>
            <div className="day-header-name">{DAYS[d.getDay()].toUpperCase()}</div>
            <div className="day-header-date">{d.getDate()} {MONTHS[d.getMonth()]}</div>
          </div>
        </div>

        {/* Hour rows */}
        {HOURS.map(h => {
          const isNow = h === nowHour
          const slotTasks = tasksByHour[h] || []
          return (
            <div key={h} className={`day-row ${isNow ? 'now-row' : ''}`}>
              <div className="day-hour-lbl">{String(h).padStart(2,'0')}h</div>
              <div className="day-slot">
                {slotTasks.map(t => {
                  const j = JOBS_DEFAULT[t.job_id] || JOBS_DEFAULT.emp1
                  const doneC = t.subtasks?.filter(s => s.done).length || 0
                  const totC  = t.subtasks?.length || 0
                  return (
                    <div key={t.id} className="day-ev" style={{ background: j.bg, borderLeftColor: j.color }}>
                      <div className="day-ev-name" style={{ color: j.text }}>{t.name}</div>
                      <div className="day-ev-sub" style={{ color: j.text }}>
                        {j.name}{totC > 0 ? ` · ${doneC}/${totC} subtarefas` : ''}
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          )
        })}

        {dayTasks.length === 0 && (
          <div style={{ gridColumn: '1/-1' }}>
            <div className="day-empty">Nenhuma tarefa com prazo neste dia 🌸</div>
          </div>
        )}
      </div>
    </div>
  )
}
