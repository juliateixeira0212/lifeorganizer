import { useState } from 'react'

export default function AuthScreen({ onSignIn, onSignUp, onGoogle }) {
  const [tab, setTab]       = useState('login')
  const [email, setEmail]   = useState('')
  const [pass, setPass]     = useState('')
  const [error, setError]   = useState('')
  const [loading, setLoading] = useState(false)

  const handle = async (e) => {
    e.preventDefault()
    setError(''); setLoading(true)
    const fn = tab === 'login' ? onSignIn : onSignUp
    const { error } = await fn({ email, password: pass })
    if (error) setError(error.message)
    setLoading(false)
  }

  return (
    <div className="auth-screen">
      <div className="auth-card">
        <div className="auth-brand">or<em>b</em>it</div>
        <div className="auth-sub">a sua agenda central 🌸</div>

        <div className="auth-tabs">
          <div className={`auth-tab ${tab==='login'?'active':''}`} onClick={() => setTab('login')}>Entrar</div>
          <div className={`auth-tab ${tab==='signup'?'active':''}`} onClick={() => setTab('signup')}>Criar conta</div>
        </div>

        <form onSubmit={handle}>
          <div className="modal-field">
            <label className="modal-label">Email</label>
            <input className="modal-input" type="email" placeholder="você@email.com" value={email} onChange={e => setEmail(e.target.value)} required />
          </div>
          <div className="modal-field">
            <label className="modal-label">Password</label>
            <input className="modal-input" type="password" placeholder="••••••••" value={pass} onChange={e => setPass(e.target.value)} required />
          </div>
          {error && <div style={{ fontSize: 12, color: 'var(--ph)', marginBottom: 12 }}>{error}</div>}
          <button className="modal-save" type="submit" disabled={loading} style={{ width: '100%', marginBottom: 8 }}>
            {loading ? 'a carregar...' : tab === 'login' ? 'Entrar' : 'Criar conta'}
          </button>
        </form>

        <div className="auth-divider"><span>ou</span></div>

        <button className="modal-cancel" style={{ width: '100%', marginBottom: 8 }} onClick={onGoogle}>
          Continuar com Google
        </button>
      </div>
    </div>
  )
}
