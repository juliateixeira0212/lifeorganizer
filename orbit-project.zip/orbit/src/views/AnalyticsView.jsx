import { JOBS_DEFAULT } from '../lib/constants'

export default function AnalyticsView({ tasks }) {
  const byJob = Object.entries(JOBS_DEFAULT).map(([jid, j]) => ({
    jid, j, hrs: tasks.filter(t => t.job_id === jid).reduce((a, t) => a + t.timer_total, 0) / 3600
  }))
  const maxH = Math.max(...byJob.map(x => x.hrs), 0.1)
  const wkDone = [4, 6, 3, 8, 5, 7, tasks.filter(t => t.done).length]
  const maxW   = Math.max(...wkDone, 1)
  const streak = Array.from({ length: 28 }, () => Math.random() > 0.35)
  const totalH = byJob.reduce((a, x) => a + x.hrs, 0) || 1

  // SVG donut
  let ang = 0
  const slices = byJob.map(({ jid, j, hrs }) => {
    const sl = (hrs / totalH) * 360
    const r  = 30
    const s1 = ang * Math.PI / 180, s2 = (ang + sl) * Math.PI / 180
    const x1 = 40 + r * Math.sin(s1), y1 = 40 - r * Math.cos(s1)
    const x2 = 40 + r * Math.sin(s2), y2 = 40 - r * Math.cos(s2)
    const lg = sl > 180 ? 1 : 0
    ang += sl
    return { jid, j, hrs, path: `M40 40 L${x1.toFixed(1)} ${y1.toFixed(1)} A${r} ${r} 0 ${lg} 1 ${x2.toFixed(1)} ${y2.toFixed(1)} Z` }
  })

  return (
    <div className="an-grid">
      <div className="an-card">
        <div className="an-title">Tarefas concluídas — 7 semanas</div>
        <div className="bar-chart">
          {wkDone.map((v, i) => (
            <div key={i} className="bar-col">
              <div className="bar-val">{v}</div>
              <div className="bar-fill" style={{ height: Math.round(v/maxW*70), background: i===6 ? 'var(--ac)' : 'var(--bg3)' }} />
              <div className="bar-label">{['S-6','S-5','S-4','S-3','S-2','S-1','Esta'][i]}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="an-card">
        <div className="an-title">Horas por emprego</div>
        <div className="donut-wrap">
          <svg width="80" height="80" viewBox="0 0 80 80">
            {slices.map(({ jid, j, path }) => (
              <path key={jid} d={path} fill={j.color} opacity=".85" />
            ))}
            <circle cx="40" cy="40" r="18" fill="var(--bg1)" />
            <text x="40" y="44" textAnchor="middle" fill="var(--t1)" fontSize="11" fontFamily="Playfair Display">{totalH.toFixed(1)}h</text>
          </svg>
          <div className="donut-legend">
            {byJob.map(({ jid, j, hrs }) => (
              <div key={jid} className="dl-item">
                <div className="dl-dot" style={{ background: j.color }} />
                {j.name}
                <div className="dl-val">{hrs.toFixed(1)}h</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="an-card">
        <div className="an-title">Streak — últimas 4 semanas</div>
        <div className="streak-row">
          {streak.map((v, i) => (
            <div key={i} className="streak-day" style={{ background: v ? 'var(--ac)' : 'var(--bg3)', opacity: v ? 1 : 0.5 }} />
          ))}
        </div>
        <div style={{ marginTop: 10, fontSize: 11, color: 'var(--t3)' }}>
          {streak.filter(Boolean).length} dias produtivos de {streak.length}
        </div>
      </div>

      <div className="an-card">
        <div className="an-title">Horas por emprego (barras)</div>
        <div className="bar-chart" style={{ height: 100 }}>
          {byJob.map(({ jid, j, hrs }) => (
            <div key={jid} className="bar-col">
              <div className="bar-val">{hrs.toFixed(1)}h</div>
              <div className="bar-fill" style={{ height: Math.round(hrs/maxH*80), background: j.color, opacity: .85 }} />
              <div className="bar-label">{j.name.split(' ')[0]}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
