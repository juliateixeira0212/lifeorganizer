import { useState } from 'react'

export default function IntegrationsView() {
  const [conn, setConn] = useState({ google: false, outlook: false })
  const toggle = (k) => setConn(c => ({ ...c, [k]: !c[k] }))

  return (
    <div>
      <div className="int-card">
        <div className="int-head">
          <div className="int-ico" style={{ background: '#f0ebff' }}>
            <svg viewBox="0 0 24 24" fill="none">
              <rect x="3" y="4" width="18" height="17" rx="2" fill="#b06af5" opacity=".8"/>
              <rect x="3" y="4" width="18" height="6" rx="2" fill="#7e3ec0"/>
              <circle cx="8" cy="15" r="1.5" fill="white"/>
              <circle cx="12" cy="15" r="1.5" fill="white"/>
              <circle cx="16" cy="15" r="1.5" fill="white"/>
            </svg>
          </div>
          <div>
            <div className="int-name">Google Calendar</div>
            <div className="int-status">
              <div className="int-sd" style={{ background: conn.google ? '#6abff5' : 'var(--t4)' }} />
              {conn.google ? 'Conectado' : 'Pronto para conectar'}
            </div>
          </div>
          <button className={`int-btn ${conn.google ? 'conn' : ''}`} onClick={() => toggle('google')}>
            {conn.google ? 'Desligar' : 'Conectar'}
          </button>
        </div>
        <div className="int-detail">Sincroniza todos os calendários Google. Time blocking automático cria eventos "Trabalhar em X" com um clique.</div>
      </div>

      <div className="int-card">
        <div className="int-head">
          <div className="int-ico" style={{ background: '#fde8f2' }}>
            <svg viewBox="0 0 24 24" fill="none">
              <rect x="2" y="3" width="14" height="18" rx="2" fill="#f56a9e" opacity=".7"/>
              <rect x="8" y="3" width="14" height="18" rx="2" fill="#f56a9e"/>
              <rect x="9" y="7" width="11" height="2" rx="1" fill="white" opacity=".9"/>
              <rect x="9" y="11" width="9" height="2" rx="1" fill="white" opacity=".7"/>
              <rect x="9" y="15" width="7" height="2" rx="1" fill="white" opacity=".5"/>
            </svg>
          </div>
          <div>
            <div className="int-name">Outlook / Microsoft 365</div>
            <div className="int-status">
              <div className="int-sd" style={{ background: conn.outlook ? '#6abff5' : 'var(--t4)' }} />
              {conn.outlook ? 'Conectado' : 'Pronto para conectar'}
            </div>
          </div>
          <button className={`int-btn ${conn.outlook ? 'conn' : ''}`} onClick={() => toggle('outlook')}>
            {conn.outlook ? 'Desligar' : 'Conectar'}
          </button>
        </div>
        <div className="int-detail">Conecta via Microsoft Graph API. Funciona com contas pessoais e M365 corporativas.</div>
      </div>

      <div className="int-card">
        <div className="int-head">
          <div className="int-ico" style={{ background: '#fff4e8' }}>
            <svg viewBox="0 0 24 24" fill="none" stroke="#f5a56a" strokeWidth="1.5" strokeLinecap="round">
              <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/>
              <polyline points="14 2 14 8 20 8"/>
              <line x1="12" y1="18" x2="12" y2="12"/>
              <line x1="9" y1="15" x2="15" y2="15"/>
            </svg>
          </div>
          <div>
            <div className="int-name">Importar .ics</div>
            <div className="int-status">
              <div className="int-sd" style={{ background: '#f5ba6a' }} />
              Workaround para agendas bloqueadas
            </div>
          </div>
        </div>
        <div className="int-detail">Exporte o .ics da agenda corporativa e importe aqui. Eventos ficam no Supabase e aparecem nas vistas de dia, semana e mês.</div>
        <div className="ics-drop">
          <svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
          <div className="ics-drop-lbl">Toque ou arraste o ficheiro .ics</div>
          <div className="ics-drop-hint">Outlook, Apple Calendar, ou qualquer agenda compatível</div>
        </div>
      </div>

      <div className="int-card">
        <div className="int-head">
          <div className="int-ico" style={{ background: '#e8f8ff' }}>
            <svg viewBox="0 0 24 24" fill="none" stroke="#6abff5" strokeWidth="1.5" strokeLinecap="round">
              <path d="M20 7H4a2 2 0 00-2 2v6a2 2 0 002 2h16a2 2 0 002-2V9a2 2 0 00-2-2z"/>
              <path d="M16 3v4M8 3v4"/>
            </svg>
          </div>
          <div>
            <div className="int-name">Supabase — base de dados</div>
            <div className="int-status">
              <div className="int-sd" style={{ background: 'var(--t4)' }} />
              Configure URL e chave anon
            </div>
          </div>
          <button className="int-btn" onClick={() => alert('Defina VITE_SUPABASE_URL e VITE_SUPABASE_ANON_KEY no ficheiro .env')}>Configurar</button>
        </div>
        <div className="int-detail">Sincroniza tudo em tempo real entre iPhone, iPad e computador. Execute o ficheiro <code>supabase/schema.sql</code> no SQL Editor do seu projeto.</div>
      </div>
    </div>
  )
}
