import { useState } from 'react'
import { JOBS_DEFAULT, fmtDate, fmtDue } from '../lib/constants'

const TODAY = new Date()

export default function NotificationsView({ tasks }) {
  const [toggles, setToggles] = useState({})
  const flip = (k) => setToggles(t => ({ ...t, [k]: !t[k] }))

  const urgent  = tasks.filter(t => !t.done && t.priority === 'alta').slice(0, 3)
  const overdue = tasks.filter(t => !t.done && t.due_date && t.due_date < fmtDate(TODAY))

  return (
    <div>
      <div className="notif-sec">Alertas ativos</div>
      {urgent.map(t => {
        const j = JOBS_DEFAULT[t.job_id] || JOBS_DEFAULT.emp1
        return (
          <div key={t.id} className="notif-card">
            <div className="notif-dot" style={{ background: 'var(--ph)' }} />
            <div className="notif-body">
              <div className="notif-title">{t.name}</div>
              <div className="notif-sub">Alta prioridade · {j.name} · {fmtDue(t.due_date, TODAY)}</div>
            </div>
            <div className="notif-time">Agora</div>
          </div>
        )
      })}
      {overdue.map(t => {
        const j = JOBS_DEFAULT[t.job_id] || JOBS_DEFAULT.emp1
        return (
          <div key={t.id} className="notif-card">
            <div className="notif-dot" style={{ background: 'var(--ph)' }} />
            <div className="notif-body">
              <div className="notif-title">Prazo ultrapassado: {t.name}</div>
              <div className="notif-sub">{j.name} · venceu {fmtDue(t.due_date, TODAY)}</div>
            </div>
            <div className="notif-time">Atrasada</div>
          </div>
        )
      })}

      <div className="notif-sec">Por emprego</div>
      <div className="sil-row">
        {Object.entries(JOBS_DEFAULT).map(([jid, j]) => (
          <div key={jid} className="sil-card">
            <div className="sil-title" style={{ color: j.color }}>{j.name}</div>
            <div className="tgl-row">
              <div className="tgl-lbl">Silencioso</div>
              <div className={`tgl ${toggles['s'+jid] ? 'on' : ''}`} onClick={() => flip('s'+jid)}>
                <div className="tgl-thumb" />
              </div>
            </div>
            <div className="tgl-row">
              <div className="tgl-lbl">Push alerts</div>
              <div className="tgl on"><div className="tgl-thumb" /></div>
            </div>
          </div>
        ))}
      </div>

      <div className="notif-sec">Digest semanal</div>
      <div className="notif-card" style={{ alignItems: 'center' }}>
        <div className="notif-body">
          <div className="notif-title">Digest de produtividade</div>
          <div className="notif-sub">Resumo enviado às segundas-feiras, 9h</div>
        </div>
        <div className={`tgl ${toggles.digest !== false ? 'on' : ''}`} onClick={() => flip('digest')}>
          <div className="tgl-thumb" />
        </div>
      </div>
    </div>
  )
}
