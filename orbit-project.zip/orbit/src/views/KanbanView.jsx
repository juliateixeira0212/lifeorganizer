import { JOBS_DEFAULT, PRIO, fmtTime } from '../lib/constants'

export default function KanbanView({ tasks }) {
  const cols = [
    { id: 'todo',  name: 'A fazer',       color: '#b06af5', items: tasks.filter(t => !t.done && (t.subtasks.length === 0 || !t.subtasks.some(s => s.done))) },
    { id: 'prog',  name: 'Em andamento',  color: '#f56a9e', items: tasks.filter(t => !t.done && t.subtasks.length > 0 && t.subtasks.some(s => s.done) && !t.subtasks.every(s => s.done)) },
    { id: 'done',  name: 'Concluídas',    color: '#6abff5', items: tasks.filter(t => t.done || (t.subtasks.length > 0 && t.subtasks.every(s => s.done))) },
  ]

  return (
    <div className="kanban-board">
      {cols.map(col => (
        <div key={col.id}>
          <div className="kb-ch">
            <div className="kb-cd" style={{ background: col.color }} />
            <div className="kb-cn">{col.name}</div>
            <div className="kb-cc">{col.items.length}</div>
          </div>
          {col.items.map(t => {
            const j = JOBS_DEFAULT[t.job_id] || JOBS_DEFAULT.emp1
            const p = PRIO[t.priority] || PRIO.media
            return (
              <div key={t.id} className="kb-card">
                <div className="kb-nm">{t.name}</div>
                <div style={{ display: 'flex', gap: 5, alignItems: 'center', flexWrap: 'wrap' }}>
                  <span className="tc-badge" style={{ background: p.bg, color: p.color, fontSize: 9, padding: '2px 7px' }}>{p.label}</span>
                  <span className="tc-badge" style={{ background: j.bg, color: j.text, fontSize: 9, padding: '2px 7px' }}>{j.name}</span>
                  {t.timer_total > 0 && <span style={{ fontSize: 9, color: 'var(--ac)', fontWeight: 600 }}>{fmtTime(t.timer_total)}</span>}
                </div>
              </div>
            )
          })}
        </div>
      ))}
    </div>
  )
}
