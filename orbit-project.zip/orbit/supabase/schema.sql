-- ================================================================
-- ORBIT — Schema Supabase
-- Execute este SQL no SQL Editor do seu projeto Supabase
-- ================================================================

-- Extensão para UUIDs
create extension if not exists "pgcrypto";

-- ── JOBS (empregos) ──────────────────────────────────────────────
create table if not exists jobs (
  id          text primary key,               -- 'emp1', 'emp2', etc.
  user_id     uuid references auth.users(id) on delete cascade,
  name        text        not null,
  color       text        not null default '#b06af5',
  bg          text        not null default 'rgba(176,106,245,.14)',
  text_color  text        not null default '#7e3ec0',
  sort_order  integer     not null default 0,
  created_at  timestamptz not null default now()
);

alter table jobs enable row level security;
create policy "users see own jobs"   on jobs for select using (auth.uid() = user_id);
create policy "users insert own jobs" on jobs for insert with check (auth.uid() = user_id);
create policy "users update own jobs" on jobs for update using (auth.uid() = user_id);
create policy "users delete own jobs" on jobs for delete using (auth.uid() = user_id);

-- ── TASKS (tarefas) ──────────────────────────────────────────────
create table if not exists tasks (
  id           uuid        primary key default gen_random_uuid(),
  user_id      uuid        references auth.users(id) on delete cascade,
  job_id       text        references jobs(id) on delete set null,
  name         text        not null,
  priority     text        not null default 'media' check (priority in ('alta','media','baixa')),
  due_date     date,
  recur        text        not null default 'none' check (recur in ('none','daily','weekly','monthly')),
  done         boolean     not null default false,
  timer_total  integer     not null default 0,      -- segundos acumulados
  sessions     integer     not null default 0,      -- sessões pomodoro
  sort_order   integer     not null default 0,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

alter table tasks enable row level security;
create policy "users see own tasks"    on tasks for select using (auth.uid() = user_id);
create policy "users insert own tasks" on tasks for insert with check (auth.uid() = user_id);
create policy "users update own tasks" on tasks for update using (auth.uid() = user_id);
create policy "users delete own tasks" on tasks for delete using (auth.uid() = user_id);

-- trigger: atualizar updated_at automaticamente
create or replace function update_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger tasks_updated_at
  before update on tasks
  for each row execute procedure update_updated_at();

-- ── SUBTASKS (subtarefas) ────────────────────────────────────────
create table if not exists subtasks (
  id         uuid        primary key default gen_random_uuid(),
  task_id    uuid        references tasks(id) on delete cascade,
  user_id    uuid        references auth.users(id) on delete cascade,
  name       text        not null,
  done       boolean     not null default false,
  sort_order integer     not null default 0,
  created_at timestamptz not null default now()
);

alter table subtasks enable row level security;
create policy "users see own subtasks"    on subtasks for select using (auth.uid() = user_id);
create policy "users insert own subtasks" on subtasks for insert with check (auth.uid() = user_id);
create policy "users update own subtasks" on subtasks for update using (auth.uid() = user_id);
create policy "users delete own subtasks" on subtasks for delete using (auth.uid() = user_id);

-- ── CALENDAR EVENTS (importados via .ics ou calendários) ─────────
create table if not exists calendar_events (
  id          uuid        primary key default gen_random_uuid(),
  user_id     uuid        references auth.users(id) on delete cascade,
  job_id      text        references jobs(id) on delete set null,
  title       text        not null,
  start_at    timestamptz not null,
  end_at      timestamptz,
  source      text        not null default 'manual'
                check (source in ('google','outlook','ics','manual','blocked')),
  external_id text,                        -- ID do evento no Google/Outlook
  all_day     boolean     not null default false,
  created_at  timestamptz not null default now()
);

alter table calendar_events enable row level security;
create policy "users see own events"    on calendar_events for select using (auth.uid() = user_id);
create policy "users insert own events" on calendar_events for insert with check (auth.uid() = user_id);
create policy "users update own events" on calendar_events for update using (auth.uid() = user_id);
create policy "users delete own events" on calendar_events for delete using (auth.uid() = user_id);

-- ── TIMER SESSIONS (histórico do cronómetro) ─────────────────────
create table if not exists timer_sessions (
  id         uuid        primary key default gen_random_uuid(),
  task_id    uuid        references tasks(id) on delete cascade,
  user_id    uuid        references auth.users(id) on delete cascade,
  started_at timestamptz not null,
  ended_at   timestamptz,
  duration   integer,                       -- segundos
  created_at timestamptz not null default now()
);

alter table timer_sessions enable row level security;
create policy "users see own sessions"    on timer_sessions for select using (auth.uid() = user_id);
create policy "users insert own sessions" on timer_sessions for insert with check (auth.uid() = user_id);
create policy "users update own sessions" on timer_sessions for update using (auth.uid() = user_id);
create policy "users delete own sessions" on timer_sessions for delete using (auth.uid() = user_id);

-- ── SEED: jobs padrão para novos utilizadores ────────────────────
-- (chame esta função depois do signup, ou use um trigger)
create or replace function seed_default_jobs(p_user_id uuid)
returns void language plpgsql security definer as $$
begin
  insert into jobs (id, user_id, name, color, bg, text_color, sort_order) values
    ('emp1', p_user_id, 'Emprego 1', '#b06af5', 'rgba(176,106,245,.14)', '#7e3ec0', 0),
    ('emp2', p_user_id, 'Emprego 2', '#f56a9e', 'rgba(245,106,158,.14)', '#a83069', 1),
    ('emp3', p_user_id, 'Freelance', '#f5a56a', 'rgba(245,165,106,.14)', '#b05a20', 2)
  on conflict (id) do nothing;
end;
$$;

-- ── ÍNDICES de performance ───────────────────────────────────────
create index if not exists tasks_user_id_idx       on tasks(user_id);
create index if not exists tasks_due_date_idx      on tasks(due_date);
create index if not exists tasks_job_id_idx        on tasks(job_id);
create index if not exists subtasks_task_id_idx    on subtasks(task_id);
create index if not exists cal_events_user_idx     on calendar_events(user_id);
create index if not exists cal_events_start_idx    on calendar_events(start_at);
create index if not exists timer_sessions_task_idx on timer_sessions(task_id);
