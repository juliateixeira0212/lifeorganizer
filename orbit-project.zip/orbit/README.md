# 🌸 Orbit — Agenda Central

Gerenciador de tarefas e agenda para múltiplos empregos. PWA instalável em iOS/iPad e desktop.

## Stack

- **React + Vite** — frontend
- **Supabase** — autenticação e base de dados em tempo real
- **Vercel** — deploy

---

## Setup local

### 1. Clonar e instalar

```bash
git clone https://github.com/SEU_UTILIZADOR/orbit.git
cd orbit
npm install
```

### 2. Criar projeto no Supabase

1. Aceda a [supabase.com](https://supabase.com) e crie um novo projeto
2. Vá ao **SQL Editor** e execute o conteúdo de `supabase/schema.sql`
3. Em **Authentication → Providers**, ative Email e (opcionalmente) Google

### 3. Configurar variáveis de ambiente

```bash
cp .env.example .env
```

Edite `.env` com os valores do seu projeto Supabase (Settings → API):

```env
VITE_SUPABASE_URL=https://xxxx.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

### 4. Correr localmente

```bash
npm run dev
```

Aceda a `http://localhost:5173`

---

## Deploy no Vercel

### Opção A — via CLI

```bash
npm install -g vercel
vercel
```

### Opção B — via GitHub (recomendado)

1. Faça push do projeto para o GitHub
2. Aceda a [vercel.com](https://vercel.com) → New Project → importe o repositório
3. Em **Environment Variables**, adicione:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
4. Clique em **Deploy**

O `vercel.json` já inclui a configuração de SPA routing.

---

## Instalar como PWA no iOS

1. Abra o URL do Vercel no **Safari** no iPhone/iPad
2. Toque no botão de partilha ↑
3. Selecione **"Adicionar ao Ecrã de Início"**
4. Confirme — o Orbit aparece como app nativa com ícone próprio

---

## Estrutura do projeto

```
orbit/
├── src/
│   ├── components/        # Topbar, Sidebar, TaskCard, TaskModal
│   ├── hooks/             # useTasks (Supabase), useAuth
│   ├── lib/               # supabase client, constants
│   ├── views/             # TasksView, DayView, WeekView, MonthView,
│   │                      # KanbanView, GanttView, AnalyticsView,
│   │                      # NotificationsView, TemplatesView, IntegrationsView
│   ├── App.jsx
│   ├── main.jsx
│   └── index.css
├── supabase/
│   └── schema.sql         # Execute no Supabase SQL Editor
├── index.html
├── vite.config.js
├── vercel.json
└── .env.example
```

## Funcionalidades

- ✅ Tarefas com subtarefas e barra de progresso
- ✅ Categorização por emprego (Emprego 1, 2, Freelance)
- ✅ Vista de Dia, Semana, Mês, Kanban, Gantt, Analytics
- ✅ Cronómetro de horas por tarefa
- ✅ Pomodoro integrado
- ✅ Tarefas recorrentes (diária/semanal/mensal)
- ✅ Templates de projetos
- ✅ Sugestão de foco IA (top 3 tarefas do dia)
- ✅ Modo foco por emprego
- ✅ Notificações e digest semanal (configurável)
- ✅ Import .ics para agendas bloqueadas
- ✅ Supabase realtime — sync iPhone ↔ iPad ↔ desktop
- ✅ Autenticação com email e Google OAuth
- ✅ PWA instalável no iOS/iPadOS

## Modo demo

Se não configurar as variáveis Supabase, o app corre em modo demo com dados locais — útil para testar sem conta.
